import { IMqttClientConnectTrait } from './traits/connect/mqtt-client.connect.trait';
import { IMqttClientOnTrait } from './traits/on/mqtt-client.on.trait';
import { IMqttClientPingLoopTrait } from './traits/ping-loop/mqtt-client.ping-loop.trait';
import { IMqttClientPingTrait } from './traits/ping/mqtt-client.ping.trait';
import { IMqttClientPublishRawTrait } from './traits/publish-raw/mqtt-client.publish-raw.trait';
import { IMqttClientPublishTrait } from './traits/publish/mqtt-client.publish.trait';
import { IMqttClientSubscribeRawTrait } from './traits/subscribe-raw/mqtt-client.subscribe-raw.trait';
import { IMqttClientSubscribeTrait } from './traits/subscribe/mqtt-client.subscribe.trait';

export interface IMqttClient extends //
  IMqttClientConnectTrait,
  IMqttClientPingTrait,
  IMqttClientPingLoopTrait,
  IMqttClientPublishRawTrait,
  IMqttClientPublishTrait,
  IMqttClientSubscribeRawTrait,
  IMqttClientSubscribeTrait,
  IMqttClientOnTrait
//
{

}
