import { IMqttClientOnFunction } from './mqtt-client.on.function-definition';

export interface IMqttClientOnTrait {
  on: IMqttClientOnFunction;
}
