import { IMqttPublishPacket } from '../../../../packets/built-in/03-mqtt-publish-packet/mqtt-publish-packet.type';
import {
  IMqttPacketTopicOrReadonlyStringBufferOrString
} from '../../../../packets/components/mqtt-packet-topic/readonly/functions/mqtt-packet-topic-or-string-buffer-or-string-to-mqtt-packet-topic';

export interface IMqttClientOnFunction {
  (
    topic: IMqttPacketTopicOrReadonlyStringBufferOrString,
  ): ReadableStream<IMqttPublishPacket>;
}
