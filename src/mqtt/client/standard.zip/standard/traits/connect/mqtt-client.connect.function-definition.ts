import { IAbortablePromiseOptions, IPromise } from '@lirx/promise';
import { IMqttConnackPacket } from '../../../../packets/built-in/02-mqtt-connack-packet/mqtt-connack-packet.type';

export interface IMqttClientConnectFunctionOptions extends IAbortablePromiseOptions {
  keepalive?: number;
}

export interface IMqttClientConnectFunction {
  (
    options?: IMqttClientConnectFunctionOptions,
  ): IPromise<IMqttConnackPacket>;
}
