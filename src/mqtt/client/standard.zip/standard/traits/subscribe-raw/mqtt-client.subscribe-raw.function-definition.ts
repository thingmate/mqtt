import { IAbortablePromiseOptions, IPromise } from '@lirx/promise';
import { IMqttSubscribePacket } from '../../../../packets/built-in/08-mqtt-subscribe-packet/mqtt-subscribe-packet.type';
import { IMqttSubackPacket } from '../../../../packets/built-in/09-mqtt-suback-packet/mqtt-suback-packet.type';

export interface IMqttClientSubscribeRawFunctionOptions extends IAbortablePromiseOptions {
}

export interface IMqttClientSubscribeRawFunction {
  (
    mqttSubscribePacket: IMqttSubscribePacket,
    options?: IMqttClientSubscribeRawFunctionOptions,
  ): IPromise<IMqttSubackPacket>;
}
