import { IMqttClientSubscribeRawFunction } from './mqtt-client.subscribe-raw.function-definition';

export interface IMqttClientSubscribeRawTrait {
  subscribeRaw: IMqttClientSubscribeRawFunction;
}
