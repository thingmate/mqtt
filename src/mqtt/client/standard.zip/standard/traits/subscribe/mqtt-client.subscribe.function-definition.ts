import { IAbortablePromiseOptions, IPromise } from '@lirx/promise';
import { QOS } from '../../../../constants/qos.enum';
import {
  MQTT_SUBSCRIBE_PACKET_SUBSCRIPTION_RETAIN_HANDLING,
} from '../../../../packets/built-in/08-mqtt-subscribe-packet/components/mqtt-subscribe-packet-subscription/traits/get-retain-handling/mqtt-subscribe-packet-subscription-retain-handling.enum';
import { IMqttSubackPacket } from '../../../../packets/built-in/09-mqtt-suback-packet/mqtt-suback-packet.type';

export interface IMqttClientSubscribeFunctionOptions extends IAbortablePromiseOptions {
  topic: string;
  qos?: QOS;
  noLocal?: boolean; // V5
  retainAsPublished?: boolean; // V5
  retainHandling?: MQTT_SUBSCRIBE_PACKET_SUBSCRIPTION_RETAIN_HANDLING; // V5
}

export interface IMqttClientSubscribeFunction {
  (
    options: IMqttClientSubscribeFunctionOptions,
  ): IPromise<IMqttSubackPacket>;
}
