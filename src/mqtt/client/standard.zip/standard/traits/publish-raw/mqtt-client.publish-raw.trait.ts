import { IMqttClientPublishRawFunction } from './mqtt-client.publish-raw.function-definition';

export interface IMqttClientPublishRawTrait {
  publishRaw: IMqttClientPublishRawFunction;
}
