import { IAbortablePromiseOptions, IPromise } from '@lirx/promise';
import { IMqttPublishPacket } from '../../../../packets/built-in/03-mqtt-publish-packet/mqtt-publish-packet.type';
import { IMqttPubackPacket } from '../../../../packets/built-in/04-mqtt-puback-packet/mqtt-puback-packet.type';
import { IMqttPubrecPacket } from '../../../../packets/built-in/05-mqtt-pubrec-packet/mqtt-pubrec-packet.type';
import { IMqttPubcompPacket } from '../../../../packets/built-in/07-mqtt-pubcomp-packet/mqtt-pubcomp-packet.type';

export interface IMqttClientPublishRawFunctionOptions extends IAbortablePromiseOptions {
}

export type IMqttPubrecAndPubcompPacketPair = [
  pubrec: IMqttPubrecPacket,
  pubcomp: IMqttPubcompPacket,
];

export type IMqttClientPublishRawFunctionResult =
  | null // qos 0
  | IMqttPubackPacket // qos 1
  | IMqttPubrecAndPubcompPacketPair // qos 2
  ;

export interface IMqttClientPublishRawFunction {
  (
    mqttPublishPacket: IMqttPublishPacket,
    options?: IMqttClientPublishRawFunctionOptions,
  ): IPromise<IMqttClientPublishRawFunctionResult>;
}
