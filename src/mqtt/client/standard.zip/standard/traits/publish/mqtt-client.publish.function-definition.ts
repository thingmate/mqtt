import { IAbortablePromiseOptions, IPromise } from '@lirx/promise';
import { QOS } from '../../../../constants/qos.enum';
import { IMqttClientPublishRawFunctionResult } from '../publish-raw/mqtt-client.publish-raw.function-definition';

export interface IMqttClientPublishFunctionOptions extends IAbortablePromiseOptions {
  topic: string;
  duplicate?: boolean;
  qos?: QOS;
  retain?: boolean;
  packetId?: number; // only if qos > 0
  // properties?: Iterable<[number, unknown]>; // V5 TODO
  payload: Uint8Array;
}

export interface IMqttClientPublishFunction {
  (
    options: IMqttClientPublishFunctionOptions,
  ): IPromise<IMqttClientPublishRawFunctionResult>;
}
