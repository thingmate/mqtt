import { IAbortablePromiseOptions, IPromise } from '@lirx/promise';

export interface IMqttClientPingFunctionOptions extends IAbortablePromiseOptions {
}

export interface IMqttClientPingFunction {
  (
    options?: IMqttClientPingFunctionOptions,
  ): IPromise<void>;
}
