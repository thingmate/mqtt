import { IMqttClientPingFunction } from './mqtt-client.ping.function-definition';

export interface IMqttClientPingTrait {
  ping: IMqttClientPingFunction;
}
