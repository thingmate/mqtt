import { IAbortablePromiseOptions, IPromise } from '@lirx/promise';
import { IMqttConnackPacket } from '../../../../packets/built-in/02-mqtt-connack-packet/mqtt-connack-packet.type';

export interface IMqttClientPingLoopFunctionOptions extends IAbortablePromiseOptions {
  keepalive: number; // in seconds
  connackPacket?: IMqttConnackPacket;
}

export interface IMqttClientPingLoopFunction {
  (
    options: IMqttClientPingLoopFunctionOptions,
  ): IPromise<void>;
}
