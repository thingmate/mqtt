import { IMqttClientPingLoopFunction } from './mqtt-client.ping-loop.function-definition';

export interface IMqttClientPingLoopTrait {
  pingLoop: IMqttClientPingLoopFunction;
}
