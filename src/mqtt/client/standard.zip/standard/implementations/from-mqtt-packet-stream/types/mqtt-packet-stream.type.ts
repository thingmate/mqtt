import { IGetReadableStream } from '../../../../../../../streams/share-readable-stream';
import { IGetWritableStream } from '../../../../../../../streams/share-writable-stream';
import { IGenericMqttPacket } from '../../../../../packets/components/mqtt-packet/mqtt-packet.type';

export interface IMqttPacketStream {
  getReadable: IGetReadableStream<IGenericMqttPacket>;
  getWritable: IGetWritableStream<IGenericMqttPacket>;
}

