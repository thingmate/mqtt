import { IMqttProtocolVersion } from '../../../../constants/mqtt-protocol-version.type';
import {
  createMqttPacketIdManager,
} from '../../../../packets/components/mqtt-packet-id-manager/implementations/create-mqtt-packet-id-manager';
import { IMqttPacketIdManager } from '../../../../packets/components/mqtt-packet-id-manager/mqtt-packet-id-manager.type';
import { IMqttClient } from '../../mqtt-client.type';
import { IMqttClientConnectFunction } from '../../traits/connect/mqtt-client.connect.function-definition';
import { IMqttClientOnFunction } from '../../traits/on/mqtt-client.on.function-definition';
import { IMqttClientPingLoopFunction } from '../../traits/ping-loop/mqtt-client.ping-loop.function-definition';
import { IMqttClientPingFunction } from '../../traits/ping/mqtt-client.ping.function-definition';
import { IMqttClientPublishRawFunction } from '../../traits/publish-raw/mqtt-client.publish-raw.function-definition';
import { IMqttClientPublishFunction } from '../../traits/publish/mqtt-client.publish.function-definition';
import { IMqttClientSubscribeRawFunction } from '../../traits/subscribe-raw/mqtt-client.subscribe-raw.function-definition';
import { IMqttClientSubscribeFunction } from '../../traits/subscribe/mqtt-client.subscribe.function-definition';
import {
  createMqttClientConnectFunctionFromMqttPacketStream,
} from './trait-implementations/connect/create-mqtt-client-connect-function-from-mqtt-packet-stream';
import {
  createMqttClientOnFunctionFromMqttPacketStream
} from './trait-implementations/on/create-mqtt-client-on-function-from-mqtt-packet-stream';
import {
  createMqttClientPingLoopFunctionFromMqttPacketStream,
} from './trait-implementations/ping-loop/create-mqtt-client-ping-loop-function-from-mqtt-packet-stream';
import {
  createMqttClientPingFunctionFromMqttPacketStream,
} from './trait-implementations/ping/create-mqtt-client-ping-function-from-mqtt-packet-stream';
import {
  createMqttClientPublishRawFunctionFromMqttPacketStream,
} from './trait-implementations/publish-raw/create-mqtt-client-publish-raw-function-from-mqtt-packet-stream';
import {
  createMqttClientPublishFunctionFromMqttPacketStream,
} from './trait-implementations/publish/create-mqtt-client-publish-function-from-mqtt-packet-stream';
import {
  createMqttClientSubscribeRawFunctionFromMqttPacketStream,
} from './trait-implementations/subscribe-raw/create-mqtt-client-subscribe-raw-function-from-mqtt-packet-stream';
import {
  createMqttClientSubscribeFunctionFromMqttPacketStream
} from './trait-implementations/subscribe/create-mqtt-client-subscribe-function-from-mqtt-packet-stream';
import {
  createMqttClientWatchFunctionFromMqttPacketStream,
} from './trait-implementations/watch/create-mqtt-client-watch-function-from-mqtt-packet-stream';
import { IMqttPacketStream } from './types/mqtt-packet-stream.type';

export interface ICreateMqttClientFromMqttPacketStreamOptions {
  protocolVersion: IMqttProtocolVersion;
  stream: IMqttPacketStream;
}

export function createMqttClientFromMqttPacketStream(
  options: ICreateMqttClientFromMqttPacketStreamOptions,
): IMqttClient {
  const packetIdManager: IMqttPacketIdManager = createMqttPacketIdManager();

  const watch = createMqttClientWatchFunctionFromMqttPacketStream({
    ...options,
    packetIdManager,
  });

  watch(); // TODO support abort

  /* PROPERTIES */

  const connect: IMqttClientConnectFunction = createMqttClientConnectFunctionFromMqttPacketStream(options);

  const ping: IMqttClientPingFunction = createMqttClientPingFunctionFromMqttPacketStream(options);

  const pingLoop: IMqttClientPingLoopFunction = createMqttClientPingLoopFunctionFromMqttPacketStream({
    ping,
  });

  const publishRaw: IMqttClientPublishRawFunction = createMqttClientPublishRawFunctionFromMqttPacketStream({
    ...options,
    packetIdManager,
  });

  const publish: IMqttClientPublishFunction = createMqttClientPublishFunctionFromMqttPacketStream({
    publishRaw,
    packetIdManager,
  });

  const subscribeRaw: IMqttClientSubscribeRawFunction = createMqttClientSubscribeRawFunctionFromMqttPacketStream(options);

  const subscribe: IMqttClientSubscribeFunction = createMqttClientSubscribeFunctionFromMqttPacketStream({
    subscribeRaw,
    packetIdManager,
  });

  const on: IMqttClientOnFunction = createMqttClientOnFunctionFromMqttPacketStream(options);

  return {
    connect,
    ping,
    pingLoop,
    publishRaw,
    publish,
    subscribeRaw,
    subscribe,
    on,
  };
}

