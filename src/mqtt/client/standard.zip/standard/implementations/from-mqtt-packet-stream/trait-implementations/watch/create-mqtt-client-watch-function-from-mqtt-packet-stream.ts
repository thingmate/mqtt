import { IAbortablePromiseOptions, IPromise, makePromiseAbortable, promiseResolve } from '@lirx/promise';
import { isMqttPubackPacket } from '../../../../../../packets/built-in/04-mqtt-puback-packet/constants/is-mqtt-puback-packet';
import { isMqttPubrecPacket } from '../../../../../../packets/built-in/05-mqtt-pubrec-packet/constants/is-mqtt-pubrec-packet';
import { createMqttPubrelPacket } from '../../../../../../packets/built-in/06-mqtt-pubrel-packet/implementations/create-mqtt-pubrel-packet';
import { isMqttPubcompPacket } from '../../../../../../packets/built-in/07-mqtt-pubcomp-packet/constants/is-mqtt-pubcomp-packet';
import { IMqttPacketIdManager } from '../../../../../../packets/components/mqtt-packet-id-manager/mqtt-packet-id-manager.type';
import {
  EMPTY_MQTT_PACKET_PROPERTY_LIST_CONSTANT,
} from '../../../../../../packets/components/mqtt-packet-property-list/readonly/constants/empty-mqtt-packet-property-list.constant';
import {
  createMqttPacketPubrelReason,
} from '../../../../../../packets/components/mqtt-packet-reason/readonly/implementations/built-in/06-pubrel/create-mqtt-packet-pubrel-reason';
import {
  PUBREL_REASON_CODE,
} from '../../../../../../packets/components/mqtt-packet-reason/readonly/implementations/built-in/06-pubrel/pubrel-reason-code.enum';
import { IGenericMqttPacket } from '../../../../../../packets/components/mqtt-packet/mqtt-packet.type';
import { IMqttPacketStream } from '../../types/mqtt-packet-stream.type';

export interface IMqttClientWatchFunctionOptions extends IAbortablePromiseOptions {
}

export interface IMqttClientWatchFunction {
  (
    options?: IMqttClientWatchFunctionOptions,
  ): IPromise<void>;
}

export interface ICreateMqttClientWatchFunctionFromMqttPacketStreamOptions {
  packetIdManager: IMqttPacketIdManager;
  stream: IMqttPacketStream;
}

export function createMqttClientWatchFunctionFromMqttPacketStream(
  {
    packetIdManager,
    stream: {
      getReadable,
      getWritable,
    },
  }: ICreateMqttClientWatchFunctionFromMqttPacketStreamOptions,
): IMqttClientWatchFunction {
  return (
    options?: IMqttClientWatchFunctionOptions,
  ): IPromise<void> => {
    const warn = (
      message: string,
    ): void => {
      console.error(message);
    };

    const writer: WritableStreamDefaultWriter<IGenericMqttPacket> = getWritable().getWriter();
    const reader: ReadableStreamDefaultReader<IGenericMqttPacket> = getReadable().getReader();

    let writePromise: IPromise<void> = promiseResolve();

    const loop = (): IPromise<void> => {
      return makePromiseAbortable(() => reader.read(), options)
        .then((result: ReadableStreamReadResult<IGenericMqttPacket>): void | IPromise<void> => {
          if (!result.done) {
            const packet: IGenericMqttPacket = result.value;

            if (isMqttPubackPacket(packet)) {
              if (!packetIdManager.has(packet.getPacketId())) {
                warn(`Received unhandled PUBACK`);
              }
            } else if (isMqttPubrecPacket(packet)) {
              if (!packetIdManager.has(packet.getPacketId())) {
                warn(`Received unhandled PUBREC`);
                writePromise = writePromise.then((): IPromise<void> => {
                  return makePromiseAbortable(() => writer.write(
                    createMqttPubrelPacket({
                      packetId: packet.getPacketId(),
                      reason: createMqttPacketPubrelReason(PUBREL_REASON_CODE.PACKET_IDENTIFIER_NOT_FOUND),
                      properties: EMPTY_MQTT_PACKET_PROPERTY_LIST_CONSTANT,
                    }),
                  ), options);
                });
              }
            } else if (isMqttPubcompPacket(packet)) {
              if (!packetIdManager.has(packet.getPacketId())) {
                warn(`Received unhandled PUBCOMP`);
              }
            }/* else if (isMqttSubackPacket(packet)) { // TODO
              if (!packetIdManager.has(packet.getPacketId())) {
                warn(`Received unhandled SUBACK`);
              }
            }*/

            return loop();
          }
        });
    };

    return loop()
      .then(() => writePromise)
      .finally(() => reader.releaseLock())
      .finally(() => writer.close())
      ;
  };
}
