import { IPromise, makePromiseAbortable } from '@lirx/promise';
import {
  STATIC_MQTT_PINGREQ_PACKET,
} from '../../../../../../packets/built-in/12-mqtt-pingreq-packet/constants/static-mqtt-pingreq-packet.constant';
import { IMqttPingreqPacket } from '../../../../../../packets/built-in/12-mqtt-pingreq-packet/mqtt-pingreq-packet.type';
import { isMqttPingrespPacket } from '../../../../../../packets/built-in/13-mqtt-pingresp-packet/constants/is-mqtt-pingresp-packet';

import { IGenericMqttPacket } from '../../../../../../packets/components/mqtt-packet/mqtt-packet.type';
import { createStreamClosedBeforePacketReceived } from '../../../../errors/_shared/create-stream-closed-before-packet-received';
import { IMqttClientPingFunction, IMqttClientPingFunctionOptions } from '../../../../traits/ping/mqtt-client.ping.function-definition';
import { IMqttPacketStream } from '../../types/mqtt-packet-stream.type';

export interface ICreateMqttClientPingFunctionFromMqttPacketStreamOptions {
  stream: IMqttPacketStream;
}

export function createMqttClientPingFunctionFromMqttPacketStream(
  {
    stream: {
      getReadable,
      getWritable,
    },
  }: ICreateMqttClientPingFunctionFromMqttPacketStreamOptions,
): IMqttClientPingFunction {
  return (
    options?: IMqttClientPingFunctionOptions,
  ): IPromise<void> => {
    const writer: WritableStreamDefaultWriter<IMqttPingreqPacket> = getWritable().getWriter();

    return makePromiseAbortable(() => writer.write(
      STATIC_MQTT_PINGREQ_PACKET,
    ), options)
      .finally((): IPromise<void> => {
        return writer.close();
      })
      .then((): IPromise<void> => {
        const reader: ReadableStreamDefaultReader<IGenericMqttPacket> = getReadable().getReader();

        const loop = (): IPromise<void> => {
          return makePromiseAbortable(() => reader.read(), options)
            .then((result: ReadableStreamReadResult<IGenericMqttPacket>): void | IPromise<void> => {
              if (result.done) {
                throw new Error(createStreamClosedBeforePacketReceived('PINGRESP')); // TODO custom message ?
              } else {
                const packet: IGenericMqttPacket = result.value;
                if (!isMqttPingrespPacket(packet)) {
                  return loop();
                }
              }
            });
        };

        return loop()
          .finally((): void => {
            return reader.releaseLock();
          });
      });
  };
}
