import { isMqttPublishPacket } from '../../../../../../packets/built-in/03-mqtt-publish-packet/constants/is-mqtt-publish-packet';
import { IMqttPublishPacket } from '../../../../../../packets/built-in/03-mqtt-publish-packet/mqtt-publish-packet.type';
import {
  IMqttPacketTopicOrReadonlyStringBufferOrString,
  mqttPacketTopicOrReadonlyStringBufferOrStringToMqttPacketTopic,
} from '../../../../../../packets/components/mqtt-packet-topic/readonly/functions/mqtt-packet-topic-or-string-buffer-or-string-to-mqtt-packet-topic';
import { IMqttPacketTopic } from '../../../../../../packets/components/mqtt-packet-topic/readonly/mqtt-packet-topic.type';

import { IGenericMqttPacket } from '../../../../../../packets/components/mqtt-packet/mqtt-packet.type';
import { IMqttClientOnFunction } from '../../../../traits/on/mqtt-client.on.function-definition';
import { IMqttPacketStream } from '../../types/mqtt-packet-stream.type';

export interface ICreateMqttClientOnFunctionFromMqttPacketStreamOptions {
  stream: Pick<IMqttPacketStream, 'getReadable'>;
}

export function createMqttClientOnFunctionFromMqttPacketStream(
  {
    stream: {
      getReadable,
    },
  }: ICreateMqttClientOnFunctionFromMqttPacketStreamOptions,
): IMqttClientOnFunction {
  return (
    topic: IMqttPacketTopicOrReadonlyStringBufferOrString,
  ): ReadableStream<IMqttPublishPacket> => {
    const _topic: IMqttPacketTopic = mqttPacketTopicOrReadonlyStringBufferOrStringToMqttPacketTopic(topic);

    const transformStream = new TransformStream<IGenericMqttPacket, IMqttPublishPacket>({
      transform: (
        packet: IGenericMqttPacket,
        controller: TransformStreamDefaultController<IMqttPublishPacket>,
      ): void => {
        if (
          isMqttPublishPacket(packet)
          && _topic.matches(packet.getTopic())
        ) {
          controller.enqueue(packet);
        }
      },
    });

    return getReadable().pipeThrough(transformStream);
  };
}
