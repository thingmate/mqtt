import { IPromise, makePromiseAbortable, promiseReject } from '@lirx/promise';
import { createReadonlyStringBufferFromString } from '../../../../../../classes/string-buffer/readonly/implementations/create-readonly-string-buffer-from-string';
import { IReadonlyStringBuffer } from '../../../../../../classes/string-buffer/readonly/readonly-string-buffer.type';
import { uuid } from '../../../../../../../misc/others/uuid';
import { IMqttProtocolVersion } from '../../../../../../constants/mqtt-protocol-version.type';
import { createMqttConnectPacket } from '../../../../../../packets/built-in/01-mqtt-connect-packet/readonly/implementations/create-mqtt-connect-packet';
import { IMqttConnectPacket } from '../../../../../../packets/built-in/01-mqtt-connect-packet/readonly/mqtt-connect-packet.type';
import { isMqttConnackPacket } from '../../../../../../packets/built-in/02-mqtt-connack-packet/constants/is-mqtt-connack-packet';
import { IMqttConnackPacket } from '../../../../../../packets/built-in/02-mqtt-connack-packet/mqtt-connack-packet.type';
import {
  EMPTY_MQTT_PACKET_PROPERTY_LIST_CONSTANT,
} from '../../../../../../packets/components/mqtt-packet-property-list/readonly/constants/empty-mqtt-packet-property-list.constant';
import {
  CONNACK_REASON_CODE
} from '../../../../../../packets/components/mqtt-packet-reason/readonly/implementations/built-in/02-connack/connack-reason-code.enum';
import { IGenericMqttPacket } from '../../../../../../packets/components/mqtt-packet/mqtt-packet.type';
import { createStreamClosedBeforePacketReceived } from '../../../../errors/_shared/create-stream-closed-before-packet-received';
import { createConnectError } from '../../../../errors/connect-error/create-connect-error';
import { createConnectErrorFromMqttConnackPacket } from '../../../../errors/connect-error/create-connect-error-from-mqtt-connack-packet';
import {
  IMqttClientConnectFunction,
  IMqttClientConnectFunctionOptions,
} from '../../../../traits/connect/mqtt-client.connect.function-definition';
import { IMqttPacketStream } from '../../types/mqtt-packet-stream.type';

// export function createPromiseFactoryLoop(
//   callback: IPromiseFactory<any>,
//   options?: IAbortablePromiseOptions,
// ): Promise<any> {
//   return callback(options)
//     .then((): Promise<any> => {
//       return createPromiseFactoryLoop(callback, options);
//     });
// }

export interface ICreateMqttClientConnectFunctionFromMqttPacketStreamOptions {
  protocolVersion: IMqttProtocolVersion;
  stream: IMqttPacketStream;
}

export function createMqttClientConnectFunctionFromMqttPacketStream(
  {
    protocolVersion,
    stream: {
      getReadable,
      getWritable,
    },
  }: ICreateMqttClientConnectFunctionFromMqttPacketStreamOptions,
): IMqttClientConnectFunction {
  const clientId: IReadonlyStringBuffer = createReadonlyStringBufferFromString(`client-${uuid()}`);
  let started: boolean;

  return (
    {
      keepalive = 60,
      ...options
    }: IMqttClientConnectFunctionOptions = {},
  ): IPromise<IMqttConnackPacket> => {
    if (started) {
      return promiseReject(`connect already done`);
    } else {
      const writer: WritableStreamDefaultWriter<IMqttConnectPacket> = getWritable().getWriter();

      return makePromiseAbortable(() => writer.write(
        createMqttConnectPacket({
          protocolName: 'MQTT',
          protocolVersion,
          clean: true,
          keepalive,
          clientId,
          properties: EMPTY_MQTT_PACKET_PROPERTY_LIST_CONSTANT,
        }),
      ), options)
        .finally((): Promise<void> => {
          return writer.close();
        })
        .then((): IPromise<IMqttConnackPacket> => {
          const reader: ReadableStreamDefaultReader<IGenericMqttPacket> = getReadable().getReader();
          return makePromiseAbortable(() => reader.read(), options)
            .then((result: ReadableStreamReadResult<IGenericMqttPacket>): IMqttConnackPacket => {
              if (result.done) {
                throw createConnectError({ message: createStreamClosedBeforePacketReceived('CONNACK') });
              } else {
                const packet: IGenericMqttPacket = result.value;
                if (isMqttConnackPacket(packet)) {
                  if (packet.getReason().getCode() === CONNACK_REASON_CODE.SUCCESS) {
                    return packet;
                  } else {
                    throw createConnectErrorFromMqttConnackPacket(packet);
                  }
                } else {
                  throw createConnectError({ message: `Expected CONNACK packet` });
                }
              }
            })
            .finally((): void => {
              return reader.releaseLock();
            });

        });
    }
  };
}
