import { IPromise, makePromiseAbortable, promiseResolve } from '@lirx/promise';
import { QOS } from '../../../../../../constants/qos.enum';
import { IMqttPublishPacket } from '../../../../../../packets/built-in/03-mqtt-publish-packet/mqtt-publish-packet.type';
import { isMqttPubackPacket } from '../../../../../../packets/built-in/04-mqtt-puback-packet/constants/is-mqtt-puback-packet';
import { IMqttPubackPacket } from '../../../../../../packets/built-in/04-mqtt-puback-packet/mqtt-puback-packet.type';
import { isMqttPubrecPacket } from '../../../../../../packets/built-in/05-mqtt-pubrec-packet/constants/is-mqtt-pubrec-packet';
import { IMqttPubrecPacket } from '../../../../../../packets/built-in/05-mqtt-pubrec-packet/mqtt-pubrec-packet.type';
import { createMqttPubrelPacket } from '../../../../../../packets/built-in/06-mqtt-pubrel-packet/implementations/create-mqtt-pubrel-packet';
import { IMqttPubrelPacket } from '../../../../../../packets/built-in/06-mqtt-pubrel-packet/mqtt-pubrel-packet.type';
import { isMqttPubcompPacket } from '../../../../../../packets/built-in/07-mqtt-pubcomp-packet/constants/is-mqtt-pubcomp-packet';
import { IMqttPacketIdManager } from '../../../../../../packets/components/mqtt-packet-id-manager/mqtt-packet-id-manager.type';
import { IMqttPacketId } from '../../../../../../packets/components/mqtt-packet-id/readonly/mqtt-packet-id.type';
import {
  EMPTY_MQTT_PACKET_PROPERTY_LIST_CONSTANT,
} from '../../../../../../packets/components/mqtt-packet-property-list/readonly/constants/empty-mqtt-packet-property-list.constant';
import {
  PUBACK_REASON_CODE,
} from '../../../../../../packets/components/mqtt-packet-reason/readonly/implementations/built-in/04-puback/puback-reason-code.enum';
import {
  PUBREC_REASON_CODE,
} from '../../../../../../packets/components/mqtt-packet-reason/readonly/implementations/built-in/05-pubrec/pubrec-reason-code.enum';
import {
  STATIC_MQTT_PACKET_PUBREL_REASON_SUCCESS,
} from '../../../../../../packets/components/mqtt-packet-reason/readonly/implementations/built-in/06-pubrel/static-mqtt-packet-pubrel-reason-success.constant';
import {
  PUBCOMP_REASON_CODE,
} from '../../../../../../packets/components/mqtt-packet-reason/readonly/implementations/built-in/07-pubcomp/pubcomp-reason-code.enum';

import { IGenericMqttPacket } from '../../../../../../packets/components/mqtt-packet/mqtt-packet.type';
import { createStreamClosedBeforePacketReceived } from '../../../../errors/_shared/create-stream-closed-before-packet-received';
import { createConnectError } from '../../../../errors/connect-error/create-connect-error';
import { createPublishError } from '../../../../errors/publish-error/create-publish-error';
import { createPublishErrorFromMqttPubackPacket } from '../../../../errors/publish-error/create-publish-error-from-mqtt-puback-packet';
import { createPublishErrorFromMqttPubcompPacket } from '../../../../errors/publish-error/create-publish-error-from-mqtt-pubcomp-packet';
import { createPublishErrorFromMqttPubrecPacket } from '../../../../errors/publish-error/create-publish-error-from-mqtt-pubrec-packet';
import {
  IMqttClientPublishRawFunction,
  IMqttClientPublishRawFunctionOptions,
  IMqttClientPublishRawFunctionResult,
  IMqttPubrecAndPubcompPacketPair,
} from '../../../../traits/publish-raw/mqtt-client.publish-raw.function-definition';
import { IMqttPacketStream } from '../../types/mqtt-packet-stream.type';

export interface ICreateMqttClientPublishRawFunctionFromMqttPacketStreamOptions {
  packetIdManager: IMqttPacketIdManager;
  stream: IMqttPacketStream;
}

export function createMqttClientPublishRawFunctionFromMqttPacketStream(
  {
    packetIdManager,
    stream: {
      getReadable,
      getWritable,
    },
  }: ICreateMqttClientPublishRawFunctionFromMqttPacketStreamOptions,
): IMqttClientPublishRawFunction {
  return (
    mqttPublishPacket: IMqttPublishPacket,
    options?: IMqttClientPublishRawFunctionOptions,
  ): IPromise<IMqttClientPublishRawFunctionResult> => {

    const packetId: IMqttPacketId = mqttPublishPacket.getPacketId() ?? packetIdManager.next();
    packetIdManager.add(packetId);
    const qos: QOS = mqttPublishPacket.getQoS();

    const writer: WritableStreamDefaultWriter<IGenericMqttPacket> = getWritable().getWriter();
    const reader: ReadableStreamDefaultReader<IGenericMqttPacket> = getReadable().getReader();

    const getAtMostOnceResponsePromise = (): IPromise<null> => {
      return promiseResolve(null);
    };

    const getAtLeastOnceResponsePromise = (): IPromise<IMqttPubackPacket> => {
      return makePromiseAbortable(() => reader.read(), options)
        .then((result: ReadableStreamReadResult<IGenericMqttPacket>): IMqttPubackPacket | IPromise<IMqttPubackPacket> => {
          if (result.done) {
            throw createPublishError({ message: `Stream closed before PUBACK packet received` });
          } else {
            const packet: IGenericMqttPacket = result.value;

            if (
              isMqttPubackPacket(packet)
              && (packet.getPacketId().get() === packetId.get())
            ) {
              if (packet.getReason().getCode() === PUBACK_REASON_CODE.SUCCESS) {
                return packet;
              } else {
                throw createPublishErrorFromMqttPubackPacket(packet);
              }
            } else {
              return getAtLeastOnceResponsePromise();
            }
          }
        });
    };

    const getExactlyOnceResponsePromise = (
      mqttPubrecPacket?: IMqttPubrecPacket,
    ): IPromise<IMqttPubrecAndPubcompPacketPair> => {
      return makePromiseAbortable(() => reader.read(), options)
        .then((result: ReadableStreamReadResult<IGenericMqttPacket>): IMqttPubrecAndPubcompPacketPair | IPromise<IMqttPubrecAndPubcompPacketPair> => {
          if (result.done) {
            throw createConnectError({ message: createStreamClosedBeforePacketReceived((mqttPubrecPacket === void 0) ? 'PUBACK' : 'PUBCOMP') });
          } else {
            const packet: IGenericMqttPacket = result.value;

            if (isMqttPubrecPacket(packet)) {
              if (packet.getPacketId().get() === packetId.get()) {
                if (packet.getReason().getCode() === PUBREC_REASON_CODE.SUCCESS) {
                  const mqttPubrelPacket: IMqttPubrelPacket = createMqttPubrelPacket({
                    packetId,
                    reason: STATIC_MQTT_PACKET_PUBREL_REASON_SUCCESS,
                    properties: EMPTY_MQTT_PACKET_PROPERTY_LIST_CONSTANT,
                  });

                  return makePromiseAbortable(() => writer.write(mqttPubrelPacket), options)
                    .then((): IPromise<IMqttPubrecAndPubcompPacketPair> => {
                      return getExactlyOnceResponsePromise(packet);
                    });
                } else {
                  throw createPublishErrorFromMqttPubrecPacket(packet);
                }
              }
            } else if (isMqttPubcompPacket(packet)) {
              if (packet.getPacketId().get() === packetId.get()) {
                if (packet.getReason().getCode() === PUBCOMP_REASON_CODE.SUCCESS) {
                  if (mqttPubrecPacket === void 0) {
                    throw createPublishError({ message: `Received PUBCOMP before PUBREC` });
                  } else {
                    return [
                      mqttPubrecPacket,
                      packet,
                    ];
                  }
                } else {
                  throw createPublishErrorFromMqttPubcompPacket(packet);
                }
              }
            }

            return getExactlyOnceResponsePromise(mqttPubrecPacket);
          }
        });
    };

    const getResponsePromise = (): IPromise<IMqttClientPublishRawFunctionResult> => {
      switch (qos) {
        case QOS.AT_MOST_ONCE:
          return getAtMostOnceResponsePromise();
        case QOS.AT_LEAST_ONCE:
          return getAtLeastOnceResponsePromise();
        case QOS.EXACTLY_ONCE:
          return getExactlyOnceResponsePromise();
      }
    };

    const _mqttPublishPacket: IMqttPublishPacket = {
      ...mqttPublishPacket,
      getPacketId: (): IMqttPacketId => {
        return packetId;
      },
    } satisfies IMqttPublishPacket;

    return makePromiseAbortable(() => writer.write(_mqttPublishPacket), options)
      .then((): IPromise<IMqttClientPublishRawFunctionResult> => {
        return getResponsePromise();
      })
      .finally((): IPromise<void> => {
        return writer.close();
      })
      .finally((): void => {
        return reader.releaseLock();
      });
  };
}
