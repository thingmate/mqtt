import { IPromise } from '@lirx/promise';
import { QOS } from '../../../../../../constants/qos.enum';
import { createMqttPublishPacket } from '../../../../../../packets/built-in/03-mqtt-publish-packet/implementations/create-mqtt-publish-packet';
import { IMqttPublishPacket } from '../../../../../../packets/built-in/03-mqtt-publish-packet/mqtt-publish-packet.type';
import { IMqttPacketIdManager } from '../../../../../../packets/components/mqtt-packet-id-manager/mqtt-packet-id-manager.type';
import { createMqttPacketId } from '../../../../../../packets/components/mqtt-packet-id/readonly/implementations/create-mqtt-packet-id';
import { IMqttPacketId } from '../../../../../../packets/components/mqtt-packet-id/readonly/mqtt-packet-id.type';
import {
  EMPTY_MQTT_PACKET_PROPERTY_LIST_CONSTANT,
} from '../../../../../../packets/components/mqtt-packet-property-list/readonly/constants/empty-mqtt-packet-property-list.constant';
import {
  createMqttPacketTopicFromString,
} from '../../../../../../packets/components/mqtt-packet-topic/readonly/implementations/create-mqtt-packet-topic-from-string';
import { IMqttPacketTopic } from '../../../../../../packets/components/mqtt-packet-topic/readonly/mqtt-packet-topic.type';
import {
  IMqttClientPublishRawFunction,
  IMqttClientPublishRawFunctionResult,
} from '../../../../traits/publish-raw/mqtt-client.publish-raw.function-definition';
import {
  IMqttClientPublishFunction,
  IMqttClientPublishFunctionOptions,
} from '../../../../traits/publish/mqtt-client.publish.function-definition';

export interface ICreateMqttClientPublishFunctionFromMqttPacketStreamOptions {
  publishRaw: IMqttClientPublishRawFunction;
  packetIdManager: IMqttPacketIdManager;
}

export function createMqttClientPublishFunctionFromMqttPacketStream(
  {
    publishRaw,
    packetIdManager,
  }: ICreateMqttClientPublishFunctionFromMqttPacketStreamOptions,
): IMqttClientPublishFunction {
  return (
    {
      topic,
      qos = QOS.AT_MOST_ONCE,
      retain = false,
      packetId,
      duplicate,
      // properties = {},
      payload,
      ...options
    }: IMqttClientPublishFunctionOptions,
  ): IPromise<IMqttClientPublishRawFunctionResult> => {

    const _topic: IMqttPacketTopic = createMqttPacketTopicFromString(topic);

    const _packetId: IMqttPacketId = (packetId === void 0)
      ? packetIdManager.next()
      : createMqttPacketId(packetId);

    const _duplicate: boolean = (duplicate === void 0)
      ? packetIdManager.has(_packetId)
      : duplicate;

    const mqttPublishPacket: IMqttPublishPacket = createMqttPublishPacket({
      topic: _topic,
      qos,
      retain,
      packetId: _packetId,
      duplicate: _duplicate,
      properties: EMPTY_MQTT_PACKET_PROPERTY_LIST_CONSTANT,
      payload,
    });

    return publishRaw(
      mqttPublishPacket,
      options,
    );
  };
}
