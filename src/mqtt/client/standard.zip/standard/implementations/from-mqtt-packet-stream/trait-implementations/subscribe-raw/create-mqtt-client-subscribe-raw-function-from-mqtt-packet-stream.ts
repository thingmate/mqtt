import { IPromise, makePromiseAbortable } from '@lirx/promise';
import { QOS } from '../../../../../../constants/qos.enum';
import {
  IMqttSubscribePacketSubscription,
} from '../../../../../../packets/built-in/08-mqtt-subscribe-packet/components/mqtt-subscribe-packet-subscription/mqtt-subscribe-packet-subscription.type';
import { IMqttSubscribePacket } from '../../../../../../packets/built-in/08-mqtt-subscribe-packet/mqtt-subscribe-packet.type';
import { isMqttSubackPacket } from '../../../../../../packets/built-in/09-mqtt-suback-packet/constants/is-mqtt-suback-packet';
import { IMqttSubackPacket } from '../../../../../../packets/built-in/09-mqtt-suback-packet/mqtt-suback-packet.type';
import { IMqttPacketId } from '../../../../../../packets/components/mqtt-packet-id/readonly/mqtt-packet-id.type';
import {
  doesSuccessSubackReasonCodeMatchQoS,
} from '../../../../../../packets/components/mqtt-packet-reason/readonly/implementations/built-in/09-suback/does-success-suback-reason-code-match-qos';
import {
  isSuccessSubackReasonCode,
} from '../../../../../../packets/components/mqtt-packet-reason/readonly/implementations/built-in/09-suback/is-success-suback-reason-code';
import {
  IMqttPacketSubackReason,
} from '../../../../../../packets/components/mqtt-packet-reason/readonly/implementations/built-in/09-suback/mqtt-packet-suback-reason.type';
import {
  SUBACK_REASON_CODE,
} from '../../../../../../packets/components/mqtt-packet-reason/readonly/implementations/built-in/09-suback/suback-reason-code.enum';

import { IGenericMqttPacket } from '../../../../../../packets/components/mqtt-packet/mqtt-packet.type';
import { createStreamClosedBeforePacketReceived } from '../../../../errors/_shared/create-stream-closed-before-packet-received';
import { createSubscribeError } from '../../../../errors/subscribe-error/create-subscribe-error';
import {
  createSubscribeErrorFromMqttSubackPacket,
} from '../../../../errors/subscribe-error/create-subscribe-error-from-mqtt-suback-packet';
import {
  IMqttClientSubscribeRawFunction,
  IMqttClientSubscribeRawFunctionOptions,
} from '../../../../traits/subscribe-raw/mqtt-client.subscribe-raw.function-definition';
import { IMqttPacketStream } from '../../types/mqtt-packet-stream.type';

export interface ICreateMqttClientSubscribeRawFunctionFromMqttPacketStreamOptions {
  stream: IMqttPacketStream;
}

export function createMqttClientSubscribeRawFunctionFromMqttPacketStream(
  {
    stream: {
      getReadable,
      getWritable,
    },
  }: ICreateMqttClientSubscribeRawFunctionFromMqttPacketStreamOptions,
): IMqttClientSubscribeRawFunction {
  return (
    mqttSubscribePacket: IMqttSubscribePacket,
    options?: IMqttClientSubscribeRawFunctionOptions,
  ): IPromise<IMqttSubackPacket> => {
    const packetId: IMqttPacketId = mqttSubscribePacket.getPacketId();
    const subscriptions: readonly IMqttSubscribePacketSubscription[] = mqttSubscribePacket.getSubscriptions();

    const writer: WritableStreamDefaultWriter<IGenericMqttPacket> = getWritable().getWriter();

    return makePromiseAbortable(() => writer.write(mqttSubscribePacket), options)
      .finally((): IPromise<void> => {
        return writer.close();
      })
      .then((): IPromise<IMqttSubackPacket> => {
        const reader: ReadableStreamDefaultReader<IGenericMqttPacket> = getReadable().getReader();

        const loop = (): IPromise<IMqttSubackPacket> => {
          return makePromiseAbortable(() => reader.read(), options)
            .then((result: ReadableStreamReadResult<IGenericMqttPacket>): IMqttSubackPacket | IPromise<IMqttSubackPacket> => {
              if (result.done) {
                throw createSubscribeError({ message: createStreamClosedBeforePacketReceived('SUBACK') });
              } else {
                const packet: IGenericMqttPacket = result.value;
                if (
                  isMqttSubackPacket(packet)
                  && (packet.getPacketId().get() === packetId.get())
                ) {
                  const reasons: readonly IMqttPacketSubackReason[] = packet.getReasons();
                  const length: number = reasons.length;

                  if (length === subscriptions.length) {
                    for (let i = 0; i < length; i++) {
                      const reasonCode: SUBACK_REASON_CODE = reasons[i].getCode();
                      const { getQoS }: IMqttSubscribePacketSubscription = subscriptions[i];
                      const qos: QOS = getQoS();

                      if (isSuccessSubackReasonCode(reasonCode)) {
                        if (!doesSuccessSubackReasonCodeMatchQoS(reasonCode, qos)) {
                          throw createSubscribeError({ message: `You asked for a QoS of ${qos} but the server only granted ${reasonCode}` });
                        }
                      } else {
                        throw createSubscribeErrorFromMqttSubackPacket(packet, i);
                      }
                    }
                    return packet;
                  } else {
                    throw createSubscribeError({ message: `SUBACK reasonCodes don't have the same length as input subscriptions` });
                  }
                } else {
                  return loop();
                }
              }
            });
        };

        return loop()
          .finally((): void => {
            return reader.releaseLock();
          });
      });
  };
}
