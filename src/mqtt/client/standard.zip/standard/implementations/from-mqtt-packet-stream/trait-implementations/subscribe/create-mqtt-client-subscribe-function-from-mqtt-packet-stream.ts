import { IPromise } from '@lirx/promise';
import { QOS } from '../../../../../../constants/qos.enum';
import {
  createMqttSubscribePacketSubscription,
} from '../../../../../../packets/built-in/08-mqtt-subscribe-packet/components/mqtt-subscribe-packet-subscription/implementations/create-mqtt-subscribe-packet-subscription';
import {
  MQTT_SUBSCRIBE_PACKET_SUBSCRIPTION_RETAIN_HANDLING,
} from '../../../../../../packets/built-in/08-mqtt-subscribe-packet/components/mqtt-subscribe-packet-subscription/traits/get-retain-handling/mqtt-subscribe-packet-subscription-retain-handling.enum';
import {
  createMqttSubscribePacket,
} from '../../../../../../packets/built-in/08-mqtt-subscribe-packet/implementations/create-mqtt-subscribe-packet';
import { IMqttSubscribePacket } from '../../../../../../packets/built-in/08-mqtt-subscribe-packet/mqtt-subscribe-packet.type';
import { IMqttSubackPacket } from '../../../../../../packets/built-in/09-mqtt-suback-packet/mqtt-suback-packet.type';
import { IMqttPacketIdManager } from '../../../../../../packets/components/mqtt-packet-id-manager/mqtt-packet-id-manager.type';
import { IMqttPacketId } from '../../../../../../packets/components/mqtt-packet-id/readonly/mqtt-packet-id.type';
import {
  EMPTY_MQTT_PACKET_PROPERTY_LIST_CONSTANT,
} from '../../../../../../packets/components/mqtt-packet-property-list/readonly/constants/empty-mqtt-packet-property-list.constant';
import {
  createMqttPacketTopicFromString,
} from '../../../../../../packets/components/mqtt-packet-topic/readonly/implementations/create-mqtt-packet-topic-from-string';
import { IMqttPacketTopic } from '../../../../../../packets/components/mqtt-packet-topic/readonly/mqtt-packet-topic.type';
import { IMqttClientSubscribeRawFunction } from '../../../../traits/subscribe-raw/mqtt-client.subscribe-raw.function-definition';
import {
  IMqttClientSubscribeFunction,
  IMqttClientSubscribeFunctionOptions,
} from '../../../../traits/subscribe/mqtt-client.subscribe.function-definition';

export interface ICreateMqttClientSubscribeFunctionFromMqttPacketStreamOptions {
  subscribeRaw: IMqttClientSubscribeRawFunction;
  packetIdManager: IMqttPacketIdManager;
}

export function createMqttClientSubscribeFunctionFromMqttPacketStream(
  {
    subscribeRaw,
    packetIdManager,
  }: ICreateMqttClientSubscribeFunctionFromMqttPacketStreamOptions,
): IMqttClientSubscribeFunction {
  return (
    {
      topic,
      qos = QOS.AT_MOST_ONCE,
      noLocal = false,
      retainAsPublished = false,
      retainHandling = MQTT_SUBSCRIBE_PACKET_SUBSCRIPTION_RETAIN_HANDLING.SEND_AT_SUBSCRIBE,
      ...options
    }: IMqttClientSubscribeFunctionOptions,
  ): IPromise<IMqttSubackPacket> => {
    const _topic: IMqttPacketTopic = createMqttPacketTopicFromString(topic);
    const packetId: IMqttPacketId = packetIdManager.next();

    const mqttSubscribePacket: IMqttSubscribePacket = createMqttSubscribePacket({
      packetId,
      properties: EMPTY_MQTT_PACKET_PROPERTY_LIST_CONSTANT,
      subscriptions: [
        createMqttSubscribePacketSubscription({
          topic: _topic,
          qos,
          noLocal,
          retainAsPublished,
          retainHandling,
        }),
      ],
    });

    return subscribeRaw({
      ...mqttSubscribePacket,
      ...options,
    });
  };
}
