import { IPromise, promiseReject, sleep } from '@lirx/promise';
import {
  IMqttClientPingLoopFunction,
  IMqttClientPingLoopFunctionOptions,
} from '../../../../traits/ping-loop/mqtt-client.ping-loop.function-definition';
import { IMqttClientPingFunction } from '../../../../traits/ping/mqtt-client.ping.function-definition';

export interface ICreateMqttClientPingFunctionFromMqttPacketStreamOptions {
  ping: IMqttClientPingFunction;
}

export function createMqttClientPingLoopFunctionFromMqttPacketStream(
  {
    ping,
  }: ICreateMqttClientPingFunctionFromMqttPacketStreamOptions,
): IMqttClientPingLoopFunction {
  let started: boolean;

  return (
    options: IMqttClientPingLoopFunctionOptions,
  ): IPromise<void> => {
    if (started) {
      return promiseReject(`ping loop already started`);
    } else {
      const serverKeepalive: number = roundServerKeepAlive(
        getServerKeepAlive(options),
      ) * 1000;

      const pingLoop = (): IPromise<void> => {
        return ping(options)
          .then((): IPromise<void> => {
            return sleep(
              serverKeepalive,
              options,
            );
          })
          .then((): IPromise<void> => {
            return pingLoop();
          });
      };

      return pingLoop();
    }
  };
}

/*-------*/

type IGetServerKeepAliveOptions = Pick<IMqttClientPingLoopFunctionOptions, 'keepalive' | 'connackPacket'>;

function getServerKeepAlive(
  {
    keepalive,
    connackPacket,
  }: IGetServerKeepAliveOptions,
): number {
  if (connackPacket === void 0) {
    return keepalive;
  } else {
    const serverKeepalive: number | undefined = connackPacket.getProperties().get('ServerKeepAlive');
    return (serverKeepalive === void 0)
      ? keepalive
      : Math.min(keepalive, serverKeepalive);
  }
}

function roundServerKeepAlive(
  serverKeepalive: number,
): number {
  return Math.max(0, serverKeepalive - 5, Math.floor(serverKeepalive * 0.8));
}

