import { IAbortablePromiseOptions } from '@lirx/promise';
import { shareReadableStream } from '../../../../../../streams/share-readable-stream';
import { shareWritableStream } from '../../../../../../streams/share-writable-stream';
import { IWebSocketStream, openWebSocketStream } from '../../../../../../streams/web-socket-stream/web-socket-stream';
import { IMqttProtocolVersion } from '../../../../constants/mqtt-protocol-version.type';
import { IGenericMqttPacket } from '../../../../packets/components/mqtt-packet/mqtt-packet.type';
import { createMqttClientFromMqttPacketStream } from '../from-mqtt-packet-stream/create-mqtt-client-from-mqtt-packet-stream';
import { createArrayBufferToMqttPacketWithTypeTransformer } from './helpers/create-array-buffer-to-mqtt-packet-with-type-transformer';
import { createMqttPacketWithTypeToUint8ArrayTransformer } from './helpers/create-mqtt-packet-with-type-to-uint8-array-transformer';
import { IWebSocketMqttClient } from './websocket-mqtt-client.type';

/*
createAbortablePromise<void>((
  resolve: IPromiseInitResolveFunction<void>,
  reject: IPromiseInitRejectFunction,
  abort$: IAbortablePromiseOnAbortFunction,
): void => {

}, options);
 */

/*-----------------*/

/*----*/

/*----*/

/*-----------------*/

export interface IOpenWebSocketMqttClientOptions extends IAbortablePromiseOptions {
  protocolVersion?: IMqttProtocolVersion,
}

export function openWebSocketMqttClient(
  url: string | URL,
  {
    protocolVersion = 5,
    ...options
  }: IOpenWebSocketMqttClientOptions = {},
): Promise<IWebSocketMqttClient> {
  return openWebSocketStream(
    url,
    {
      ...options,
      binaryType: 'arraybuffer',
      protocols: ['mqtt'],
    },
  )
    .then((websocketStream: IWebSocketStream): IWebSocketMqttClient => {

      const readable: ReadableStream<IGenericMqttPacket> = websocketStream.readable
        .pipeThrough(
          createArrayBufferToMqttPacketWithTypeTransformer({
            protocolVersion,
          }),
        );

      const transformer = createMqttPacketWithTypeToUint8ArrayTransformer({
        protocolVersion,
      });

      transformer.readable.pipeTo(websocketStream.writable); // TODO await ?

      const writable: WritableStream<IGenericMqttPacket> = transformer.writable;

      const getReadable = shareReadableStream(readable);
      const getWritable = shareWritableStream(writable);

      const stream = {
        getReadable,
        getWritable,
      };

      return {
        ...createMqttClientFromMqttPacketStream({
          protocolVersion,
          stream,
        }),
        // close,
        // close$,
        // error$,
      };
    });

}
