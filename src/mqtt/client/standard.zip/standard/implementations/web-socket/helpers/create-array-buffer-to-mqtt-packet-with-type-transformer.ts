import { IByteIteratorDecoder } from '../../../../../../misc/codec/byte-iterator-decoder.type';
import { IMqttProtocolVersion } from '../../../../../constants/mqtt-protocol-version.type';
import {
  createByteIteratorDecoderForMqttPacket,
} from '../../../../../packets/components/mqtt-packet/implementations/functions/create-byte-iterator-decoder-for-mqtt-packet';
import {
  generateGetExtraArgumentsFunctionForMqttPacketByteIteratorDecoder,
} from '../../../../../packets/components/mqtt-packet/implementations/functions/extra-arguments/generate-get-extra-arguments-function-for-mqtt-packet-byte-iterator-decoder';
import { IGenericMqttPacket } from '../../../../../packets/components/mqtt-packet/mqtt-packet.type';

export interface ICreateArrayBufferToMqttPacketWithTypeTransformerOptions {
  protocolVersion: IMqttProtocolVersion,
}

export function createArrayBufferToMqttPacketWithTypeTransformer(
  {
    protocolVersion,
  }: ICreateArrayBufferToMqttPacketWithTypeTransformerOptions,
): TransformStream<ArrayBuffer, IGenericMqttPacket> {
  let decoder: IByteIteratorDecoder<never>;

  return new TransformStream<ArrayBuffer, IGenericMqttPacket>({
    start: (
      controller: TransformStreamDefaultController<IGenericMqttPacket>,
    ): void => {
      const getExtraArguments = generateGetExtraArgumentsFunctionForMqttPacketByteIteratorDecoder(() => protocolVersion);

      function* createByteIteratorLoopDecoderForMqttPacketWithType(): IByteIteratorDecoder<never> {
        while (true) {
          const packetWithType: IGenericMqttPacket = yield* createByteIteratorDecoderForMqttPacket(getExtraArguments);
          controller.enqueue(packetWithType);
        }
      }

      decoder = createByteIteratorLoopDecoderForMqttPacketWithType();
      decoder.next();
    },
    transform: (
      buffer: ArrayBuffer,
    ): void => {
      const bytes: Uint8Array = new Uint8Array(buffer);
      for (let i = 0, l = bytes.length; (i < l); i++) {
        decoder.next(bytes[i]);
      }
    },
  });
}
