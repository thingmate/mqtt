import { IMqttClient } from '../../mqtt-client.type';

export interface IWebSocketMqttClientCloseFunction {
  (
    code?: number,
    reason?: string,
  ): Promise<void>;
}

export interface IWebSocketMqttClient extends IMqttClient {
  // readonly close: IWebSocketMqttClientCloseFunction; // TODO trait
  // readonly error$: IObservable<Error>;
  // readonly close$: IObservable<CloseEvent>;
}
